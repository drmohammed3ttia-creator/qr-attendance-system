"use client";

const STORAGE_KEY = "qr_attendance_device_id";

/**
 * يُنشئ (أو يسترجع) معرّف جهاز عشوائي وثابت (persistent) لهذا المتصفح،
 * ويُخزَّن في localStorage بحيث يبقى نفسه بين الجلسات على نفس الجهاز.
 * يُستخدم فقط كطرف عميل — التحقق والربط الفعلي يتم بالكامل على السيرفر
 * (انظر lib/device.ts والتعليق فيه لشرح حدود هذا الأسلوب).
 */
export function getOrCreateDeviceId(): string {
  if (typeof window === "undefined") return "";
  try {
    const existing = window.localStorage.getItem(STORAGE_KEY);
    if (existing) return existing;
    const id = crypto.randomUUID();
    window.localStorage.setItem(STORAGE_KEY, id);
    return id;
  } catch {
    // localStorage غير متاح (مثلاً وضع تصفح خاص صارم يمنعه) — نولّد معرّفًا
    // مؤقتًا لهذه الجلسة فقط بدل تعطيل الصفحة بالكامل. لن يبقى ثابتًا بين
    // الجلسات في هذه الحالة تحديدًا.
    return crypto.randomUUID();
  }
}
