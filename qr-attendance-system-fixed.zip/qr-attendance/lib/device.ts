import crypto from "crypto";

/**
 * ربط "جهاز واحد لكل طالب" (device binding)
 * -------------------------------------------
 * الجهاز يُعرَّف عبر معرّف عشوائي (UUID) يُنشئه المتصفح مرة واحدة عبر
 * crypto.randomUUID() ويُخزَّن في localStorage (انظر lib/device-client.ts) —
 * وليس عبر IP أو User-Agent كما طُلب صراحةً، لأن كليهما يتغيران بسهولة
 * (شبكة مختلفة، تحديث المتصفح) أو يتشابهان بين أجهزة مختلفة على نفس
 * الشبكة، فلا يصلحان كهوية جهاز.
 *
 * هذا المعرّف الخام (raw device id) لا يُخزَّن أبدًا في القاعدة. بدلاً من
 * ذلك نخزّن فقط HMAC-SHA256(DEVICE_ID_HASH_SECRET, deviceId) — hash
 * مفتاحي بسر لا يعرفه إلا السيرفر، بحيث حتى لو تسرّبت قاعدة البيانات لا
 * يمكن ربط الـ hash المخزَّن بمعرّف جهاز فعلي أو التنبؤ بقيم صالحة أخرى.
 *
 * ⚠️ حدود صادقة لهذا الأسلوب (لا يوجد بديل كامل من متصفح ويب عادي بدون
 * تطبيق أصلي/native): لو مسح الطالب بيانات المتصفح (localStorage) أو
 * استخدم نافذة تصفح خاص (incognito) على نفس الهاتف الفعلي، سيُنشأ معرّف
 * جهاز جديد من منظور السيرفر — أي أن "الجهاز الفعلي" نفسه قد يظهر كجهاز
 * مختلف. هذا قيد معروف لأي حل قائم على المتصفح وليس خطأ في هذا التطبيق؛
 * حل هذه الفجوة تمامًا يتطلب تطبيقًا أصليًا (iOS/Android) بهوية جهاز
 * حقيقية (Keychain/Keystore) وهو خارج نطاق نظام ويب فقط.
 */

export function hashDeviceId(rawDeviceId: string): string {
  const secret = process.env.DEVICE_ID_HASH_SECRET;
  if (!secret) {
    throw new Error(
      "DEVICE_ID_HASH_SECRET is not configured on the server (see .env.example)"
    );
  }
  return crypto.createHmac("sha256", secret).update(rawDeviceId).digest("hex");
}

/** فحص شكلي أساسي فقط (طول معقول) — لا نتحقق من محتوى المعرّف لأنه UUID عشوائي بحت */
export function isPlausibleDeviceId(value: unknown): value is string {
  return typeof value === "string" && value.length >= 16 && value.length <= 128;
}
