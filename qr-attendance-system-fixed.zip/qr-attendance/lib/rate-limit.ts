/**
 * Rate limiter بواجهة async موحّدة، بمصدرين ممكنين:
 *
 * 1) Upstash Redis عبر REST API — يُفعَّل تلقائيًا فقط إذا كانت
 *    UPSTASH_REDIS_REST_URL و UPSTASH_REDIS_REST_TOKEN معرَّفتين في
 *    متغيرات البيئة. تعمّدنا استخدام REST مباشرةً بدون حزمة npm
 *    (@upstash/redis أو @upstash/ratelimit) لتفادي إضافة تبعية جديدة
 *    وتبسيط الأمر — فقط fetch عادي، وهذا متوافق تمامًا مع بيئات
 *    serverless/edge (Vercel).
 *
 * 2) نسخة احتياطية في الذاكرة (in-memory) — تُستخدم تلقائيًا إذا لم يتم
 *    ضبط متغيرات Upstash (مثلاً أثناء التطوير المحلي). ⚠️ نفس القيد
 *    السابق يبقى قائمًا: هذه النسخة لا تعمل بشكل موثوق عبر عدة instances
 *    منفصلة في بيئة serverless حقيقية (كل instance له ذاكرته الخاصة)،
 *    لذا لا يجب الاعتماد عليها في الإنتاج — هي fallback للتطوير المحلي
 *    فقط أو لبيئة بها instance واحد طويل العمر.
 *
 * ⚠️ ملاحظة صادقة: مسار Upstash مكتوب حسب توثيق REST API الخاص بهم
 * (POST /pipeline بأوامر INCR ثم EXPIRE)، لكن لم يُختبر فعليًا ضد حساب
 * Upstash حقيقي في بيئة إعداد هذا الكود (لا يوجد اتصال شبكة خارجي متاح
 * هنا). الرجاء اختباره يدويًا (راجع قسم الاختبار في README) بعد ربط
 * مشروع Upstash فعلي قبل الاعتماد عليه في الإنتاج.
 */

const UPSTASH_URL = process.env.UPSTASH_REDIS_REST_URL;
const UPSTASH_TOKEN = process.env.UPSTASH_REDIS_REST_TOKEN;

type RateLimitResult = { allowed: boolean; retryAfterMs?: number };

// ---------------------------------------------------------------------
// Backend 1: Upstash Redis (REST)
// ---------------------------------------------------------------------
async function upstashRateLimit(
  key: string,
  maxRequests: number,
  windowMs: number
): Promise<RateLimitResult> {
  const windowSeconds = Math.max(1, Math.ceil(windowMs / 1000));
  const redisKey = `ratelimit:${key}`;

  try {
    // pipeline بأمر واحد شبكيًا: INCR ثم EXPIRE NX (يضبط الصلاحية فقط
    // عند أول INCR ينشئ المفتاح، بدون إعادة تصفير النافذة الزمنية مع كل طلب)
    const res = await fetch(`${UPSTASH_URL}/pipeline`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${UPSTASH_TOKEN}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify([
        ["INCR", redisKey],
        ["EXPIRE", redisKey, String(windowSeconds), "NX"],
      ]),
    });

    if (!res.ok) {
      console.error("Upstash rate-limit request failed:", res.status, await res.text().catch(() => ""));
      // فشل خدمة الـ rate limiting نفسها لا يجب أن يمنع الطلاب من تسجيل
      // الحضور بالكامل — نفشل بأمان (fail-open) هنا تحديدًا لأن هذا حد
      // مضاد لإساءة الاستخدام فقط، وليس تحققًا أمنيًا جوهريًا (ذلك يقع في
      // /api/attendance/confirm عبر توقيع QR والتحقق من التسجيل والجهاز)
      return { allowed: true };
    }

    const results = (await res.json()) as Array<{ result: number | null; error?: string }>;
    const count = Number(results?.[0]?.result ?? 0);

    if (count > maxRequests) {
      return { allowed: false, retryAfterMs: windowSeconds * 1000 };
    }
    return { allowed: true };
  } catch (err) {
    console.error("Upstash rate-limit error:", err);
    return { allowed: true }; // fail-open لنفس السبب أعلاه
  }
}

// ---------------------------------------------------------------------
// Backend 2: in-memory (fallback للتطوير المحلي فقط)
// ---------------------------------------------------------------------
type Bucket = { count: number; resetAt: number };
const memoryBuckets = new Map<string, Bucket>();

function memoryRateLimit(key: string, maxRequests: number, windowMs: number): RateLimitResult {
  const now = Date.now();
  const bucket = memoryBuckets.get(key);

  if (!bucket || bucket.resetAt < now) {
    memoryBuckets.set(key, { count: 1, resetAt: now + windowMs });
    return { allowed: true };
  }

  if (bucket.count >= maxRequests) {
    return { allowed: false, retryAfterMs: bucket.resetAt - now };
  }

  bucket.count += 1;
  return { allowed: true };
}

// ---------------------------------------------------------------------
// الواجهة العامة المستخدمة في بقية الكود
// ---------------------------------------------------------------------
export async function rateLimit(
  key: string,
  maxRequests: number,
  windowMs: number
): Promise<RateLimitResult> {
  if (UPSTASH_URL && UPSTASH_TOKEN) {
    return upstashRateLimit(key, maxRequests, windowMs);
  }
  return memoryRateLimit(key, maxRequests, windowMs);
}

/** تنظيف دوري بسيط للنسخة في الذاكرة فقط (Redis يتولى الصلاحية بنفسه عبر EXPIRE) */
export function cleanupRateLimitBuckets() {
  if (UPSTASH_URL && UPSTASH_TOKEN) return;
  if (Math.random() > 0.01) return;
  const now = Date.now();
  for (const [key, bucket] of memoryBuckets) {
    if (bucket.resetAt < now) memoryBuckets.delete(key);
  }
}
