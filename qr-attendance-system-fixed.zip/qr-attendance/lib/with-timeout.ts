// يضمن أن أي Promise (خصوصًا نداءات Supabase auth) لا يبقى معلّقًا إلى
// الأبد — حتى لو كان السبب تعليق داخلي (مثل قفل navigator.locks) لا يُنتج
// خطأ ولا يُرسل طلب شبكة إطلاقًا. بعد المهلة، تُرفض القيمة العائدة برسالة
// واضحة يلتقطها catch في معالج تسجيل الدخول.
export function withTimeout<T>(promise: Promise<T>, ms = 12000, label = "الطلب"): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => {
      reject(new Error(`انتهت مهلة ${label} (${ms / 1000} ثانية). تحقق من اتصالك بالإنترنت وحاول مرة أخرى.`));
    }, ms);

    promise
      .then((value) => {
        clearTimeout(timer);
        resolve(value);
      })
      .catch((err) => {
        clearTimeout(timer);
        reject(err);
      });
  });
}
