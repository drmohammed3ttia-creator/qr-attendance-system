import crypto from "crypto";

/**
 * فكرة عمل الـ QR الديناميكي:
 * -------------------------------
 * كل جلسة حضور (attendance_session) لها secret_key عشوائي فريد (32 بايت)
 * يُخزَّن في القاعدة ولا يُرسل أبدًا للعميل.
 *
 * الـ QR المعروض على الشاشة لا يحتوي رابطًا ثابتًا، بل يحتوي:
 *   sessionId . window . signature
 * حيث:
 *   window    = الطابع الزمني الحالي مقسومًا على 25 ثانية (نافذة زمنية تتجدد تلقائيًا)
 *   signature = HMAC-SHA256(secret_key, sessionId + ":" + window)
 *
 * صفحة عرض الـ QR (شاشة الدكتور) تستدعي /api/qr/token كل بضع ثوانٍ
 * لتوليد التوقيع الخاص بالنافذة الحالية — التوقيع نفسه يُحسب واستدعاء
 * حسابه يتطلب secret_key الموجود فقط على السيرفر، لذا لا يمكن لأي طالب
 * توليد توقيع صالح بنفسه حتى لو عرف الخوارزمية.
 *
 * عند المسح، الطالب يرسل sessionId + window + signature إلى
 * /api/attendance/confirm الذي يتحقق من:
 *   1) أن window لا يزال ضمن هامش السماح (نافذة حالية أو سابقة واحدة فقط)
 *   2) أن التوقيع مطابق لما يُحسب سيرفريًا بنفس secret_key
 *   3) أن الجلسة لا تزال open ولم تنتهِ صلاحيتها (closes_at)
 * فإذا صوّر طالب الشاشة وأرسل الصورة لزميله بعد أكثر من ~50 ثانية، يصبح
 * الرمز غير صالح تلقائيًا.
 */

export const QR_WINDOW_SECONDS = 25;

export function currentWindow(): number {
  return Math.floor(Date.now() / 1000 / QR_WINDOW_SECONDS);
}

export function signWindow(secretKey: string, sessionId: string, window: number): string {
  return crypto
    .createHmac("sha256", secretKey)
    .update(`${sessionId}:${window}`)
    .digest("hex");
}

export function verifyWindow(
  secretKey: string,
  sessionId: string,
  window: number,
  signature: string
): { valid: boolean; reason?: string } {
  const nowWindow = currentWindow();

  // نسمح بالنافذة الحالية أو السابقة فقط (هامش تسامح لبطء الشبكة/المسح)
  if (window !== nowWindow && window !== nowWindow - 1) {
    return { valid: false, reason: "QR code expired, please rescan" };
  }

  const expected = signWindow(secretKey, sessionId, window);
  const expectedBuf = Buffer.from(expected, "hex");
  const givenBuf = Buffer.from(signature || "", "hex");

  if (
    expectedBuf.length !== givenBuf.length ||
    !crypto.timingSafeEqual(expectedBuf, givenBuf)
  ) {
    return { valid: false, reason: "Invalid QR signature" };
  }

  return { valid: true };
}

export function generateSecretKey(): string {
  return crypto.randomBytes(32).toString("hex");
}

/** الرابط الذي يُرمَّز داخل صورة الـ QR */
export function buildQrPayload(baseUrl: string, sessionId: string, window: number, signature: string) {
  const url = new URL(`/student/attend/${sessionId}`, baseUrl);
  url.searchParams.set("w", String(window));
  url.searchParams.set("s", signature);
  return url.toString();
}
