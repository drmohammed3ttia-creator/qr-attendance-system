import { createBrowserClient } from "@supabase/ssr";
import type { SupabaseClient } from "@supabase/supabase-js";

// عميل واحد فقط لكل تبويب متصفح (singleton).
//
// السبب الجذري لتعليق "جارٍ الدخول..." للأبد بدون أي طلب في سجلات Supabase:
// كانت createClient() تُنشئ GoTrueClient جديدًا تمامًا في كل استدعاء، وهي
// تُستدعى من 6+ أماكن منفصلة (صفحة دخول المحاضر، لوحة التحكم، صفحة الطالب،
// صفحة الحضور، صفحة دخول الطالب). عميل مصادقة Supabase (v2) ينسّق عمليات
// الدخول/التجديد/الخروج بين النسخ المختلفة عبر Navigator LockManager
// (navigator.locks) بنفس مفتاح التخزين. وجود عدة نسخ من العميل حيّة في نفس
// التبويب يجعل signInWithPassword ينتظر أولاً الحصول على القفل — وقد يعلّق
// إلى الأبد قبل إرسال أي طلب شبكة فعلي إذا كانت نسخة أخرى تحتفظ بالقفل أو
// تنتظره. حل هذا هو استخدام نسخة واحدة فقط طوال عمر التبويب.
let client: SupabaseClient | undefined;

export function createClient() {
  if (client) return client;

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  // على Vercel، هذه القيم يجب أن تكون مضبوطة في Project Settings > Environment
  // Variables (لكل من Production و Preview و Development) ثم يُعاد النشر.
  // بدون هذا التحقق، القيمة الناقصة تمر بصمت وأي خطأ لاحق كان يُفلت بدون
  // try/catch في صفحة الدخول، فيبقى الزر عالقًا على "جارٍ الدخول..." للأبد.
  if (!url || !anonKey) {
    throw new Error(
      "Supabase env vars missing: NEXT_PUBLIC_SUPABASE_URL و/أو NEXT_PUBLIC_SUPABASE_ANON_KEY غير مضبوطتين. تحقق من إعدادات البيئة في Vercel وأعد النشر."
    );
  }

  // createBrowserClient (وليس @supabase/supabase-js مباشرة) لأن الجلسة يجب أن
  // تُكتب في الكوكيز حتى تستطيع الـ middleware ومسارات /api/* قراءتها على
  // الخادم عبر createServerSupabase — استخدام تخزين localStorage بدلاً من
  // ذلك كان سيُسجّل الدخول في المتصفح بنجاح لكن يفشل كل طلب API لاحقًا.
  client = createBrowserClient(url, anonKey);
  return client;
}
