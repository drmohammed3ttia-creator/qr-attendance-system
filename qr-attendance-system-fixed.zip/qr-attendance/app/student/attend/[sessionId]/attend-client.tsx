"use client";
import { useEffect, useState } from "react";
import { useParams, useSearchParams, useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { getOrCreateDeviceId } from "@/lib/device-client";

type Status = "checking" | "needLogin" | "ready" | "submitting" | "success" | "error";

export default function AttendClient() {
  const params = useParams<{ sessionId: string }>();
  const search = useSearchParams();
  const router = useRouter();

  const [status, setStatus] = useState<Status>("checking");
  const [message, setMessage] = useState<string>("");
  const [scannedAt, setScannedAt] = useState<string | null>(null);

  const window_ = search.get("w");
  const signature = search.get("s");

  useEffect(() => {
    async function check() {
      const supabase = createClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) {
        // نحفظ الوجهة كي يعود الطالب هنا بعد تسجيل الدخول
        const redirect = encodeURIComponent(
          `/student/attend/${params.sessionId}?w=${window_}&s=${signature}`
        );
        router.replace(`/student/login?redirect=${redirect}`);
        return;
      }
      setStatus("ready");
    }
    check();
  }, [params.sessionId, window_, signature, router]);

  async function confirmAttendance() {
    setStatus("submitting");
    let gpsLat: number | undefined;
    let gpsLng: number | undefined;

    // نحاول الحصول على GPS بشكل اختياري (لا نمنع التسجيل إن رفض الطالب الإذن،
    // إلا إذا كانت الجلسة تفرض ذلك، فسيرفضها السيرفر برسالة واضحة)
    try {
      const pos = await new Promise<GeolocationPosition>((resolve, reject) =>
        navigator.geolocation.getCurrentPosition(resolve, reject, { timeout: 4000 })
      );
      gpsLat = pos.coords.latitude;
      gpsLng = pos.coords.longitude;
    } catch {
      /* تجاهل — قد لا تكون مطلوبة */
    }

    const deviceId = getOrCreateDeviceId();

    const res = await fetch("/api/attendance/confirm", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        sessionId: params.sessionId,
        window: Number(window_),
        signature,
        gpsLat,
        gpsLng,
        deviceId,
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      setStatus("error");
      setMessage(data.error || "حدث خطأ أثناء تسجيل الحضور");
      return;
    }
    setStatus("success");
    setScannedAt(data.scannedAt);
  }

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center px-4">
      <div className="w-full max-w-sm bg-white rounded-2xl shadow-sm border border-slate-200 p-8 text-center">
        {status === "checking" && <p className="text-slate-500">جارٍ التحقق...</p>}

        {status === "ready" && (
          <>
            <h1 className="text-lg font-semibold text-slate-900 mb-2">تأكيد الحضور</h1>
            <p className="text-sm text-slate-500 mb-6">اضغط الزر أدناه لتسجيل حضورك لهذه المحاضرة</p>
            <button
              onClick={confirmAttendance}
              className="w-full bg-brand-600 hover:bg-brand-700 text-white rounded-lg py-3 text-sm font-medium transition"
            >
              Confirm Attendance
            </button>
          </>
        )}

        {status === "submitting" && <p className="text-slate-500">جارٍ التسجيل...</p>}

        {status === "success" && (
          <>
            <div className="text-4xl mb-3">✓</div>
            <p className="text-lg font-semibold text-green-700">Attendance Recorded Successfully</p>
            {scannedAt && (
              <p className="text-sm text-slate-500 mt-2">
                وقت التسجيل: {new Date(scannedAt).toLocaleTimeString("ar-EG")}
              </p>
            )}
          </>
        )}

        {status === "error" && (
          <>
            <div className="text-4xl mb-3 text-red-500">✕</div>
            <p className="text-red-600 font-medium">{message}</p>
          </>
        )}
      </div>
    </div>
  );
}
