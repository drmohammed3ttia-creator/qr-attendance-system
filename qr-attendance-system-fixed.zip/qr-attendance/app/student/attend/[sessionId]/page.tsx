import { Suspense } from "react";
import AttendClient from "./attend-client";

function AttendFallback() {
  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center px-4">
      <div className="w-full max-w-sm bg-white rounded-2xl shadow-sm border border-slate-200 p-8 text-center">
        <p className="text-slate-500">جارٍ التحقق...</p>
      </div>
    </div>
  );
}

export default function AttendPage() {
  return (
    <Suspense fallback={<AttendFallback />}>
      <AttendClient />
    </Suspense>
  );
}
