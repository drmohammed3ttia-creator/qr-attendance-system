"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

// صفحة الطالب الافتراضية بعد تسجيل الدخول بدون رابط QR (مثلاً لو دخل يدويًا
// على /student/login بدون مسح كود). قبل هذا الإصلاح لم تكن هذه الصفحة
// موجودة إطلاقًا، فكان التوجيه الافتراضي في صفحة تسجيل الدخول يؤدي لـ 404.
export default function StudentHomePage() {
  const router = useRouter();
  const [fullName, setFullName] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const supabase = createClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) {
        router.replace("/student/login");
        return;
      }
      const { data: profile } = await supabase
        .from("users_profile")
        .select("full_name")
        .eq("id", user.id)
        .maybeSingle();
      setFullName(profile?.full_name ?? null);
      setLoading(false);
    }
    load();
  }, [router]);

  async function logout() {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push("/student/login");
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center text-slate-400">
        جارٍ التحميل...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center px-4">
      <div className="w-full max-w-sm bg-white rounded-2xl shadow-sm border border-slate-200 p-8 text-center">
        <h1 className="text-lg font-semibold text-slate-900 mb-1">
          {fullName ? `مرحبًا، ${fullName}` : "مرحبًا"}
        </h1>
        <p className="text-sm text-slate-500 mb-6">
          لتسجيل حضورك، امسح رمز QR المعروض في قاعة المحاضرة من دكتورك.
        </p>
        <button
          onClick={logout}
          className="w-full bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 rounded-lg py-2.5 text-sm font-medium transition"
        >
          تسجيل الخروج
        </button>
      </div>
    </div>
  );
}
