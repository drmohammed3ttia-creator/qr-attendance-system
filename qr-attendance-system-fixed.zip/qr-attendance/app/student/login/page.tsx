import { Suspense } from "react";
import StudentLoginClient from "./login-client";

function StudentLoginFallback() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 px-4">
      <div className="w-full max-w-sm bg-white rounded-2xl shadow-sm border border-slate-200 p-8">
        <p className="text-sm text-slate-500">جارٍ التحميل...</p>
      </div>
    </div>
  );
}

export default function StudentLoginPage() {
  return (
    <Suspense fallback={<StudentLoginFallback />}>
      <StudentLoginClient />
    </Suspense>
  );
}
