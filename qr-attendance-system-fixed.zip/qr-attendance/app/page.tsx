import Link from "next/link";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center px-4">
      <div className="text-center max-w-md">
        <h1 className="text-2xl font-bold text-slate-900 mb-2">نظام تسجيل الحضور بـ QR Code</h1>
        <p className="text-slate-500 mb-8">اختر نوع الحساب للدخول</p>
        <div className="flex gap-4 justify-center">
          <Link
            href="/lecturer/login"
            className="bg-brand-600 hover:bg-brand-700 text-white rounded-lg px-6 py-3 text-sm font-medium transition"
          >
            دخول عضو هيئة التدريس
          </Link>
          <Link
            href="/student/login"
            className="bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 rounded-lg px-6 py-3 text-sm font-medium transition"
          >
            دخول الطالب
          </Link>
        </div>
      </div>
    </div>
  );
}
