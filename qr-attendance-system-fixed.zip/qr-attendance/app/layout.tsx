import "./globals.css";

export const metadata = {
  title: "نظام تسجيل الحضور بـ QR Code",
  description: "University QR Attendance System",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body className="font-sans antialiased text-slate-900">{children}</body>
    </html>
  );
}
