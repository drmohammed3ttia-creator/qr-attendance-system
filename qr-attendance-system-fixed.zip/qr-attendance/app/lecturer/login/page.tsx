"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { withTimeout } from "@/lib/with-timeout";
import { useRouter } from "next/navigation";

export default function LecturerLoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    if (loading) return; // يمنع نقرات متكررة قد تُنشئ طلبات متزامنة إضافية
    setLoading(true);
    setError(null);

    try {
      const supabase = createClient();
      const { error } = await withTimeout(
        supabase.auth.signInWithPassword({ email, password }),
        12000,
        "تسجيل الدخول"
      );

      if (error) {
        setError("بيانات الدخول غير صحيحة");
        return;
      }

      router.push("/lecturer/dashboard");
      router.refresh();
    } catch (err) {
      // يلتقط أي خطأ غير متوقع: متغيرات بيئة Supabase غير مضبوطة على Vercel،
      // فشل في الشبكة، تعليق داخلي (navigator.locks) تجاوز المهلة، أو أي
      // استثناء آخر — بدون هذا الالتقاط كانت الحالة "loading" تبقى معلّقة
      // إلى الأبد لأن setLoading(false) لم تكن تُنفَّذ أبدًا
      console.error("[lecturer-login] unexpected error:", err);
      setError(err instanceof Error ? err.message : "تعذّر الاتصال بالخادم. يرجى المحاولة مرة أخرى.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 px-4">
      <div className="w-full max-w-sm bg-white rounded-2xl shadow-sm border border-slate-200 p-8">
        <h1 className="text-xl font-semibold text-slate-900 mb-1">تسجيل دخول عضو هيئة التدريس</h1>
        <p className="text-sm text-slate-500 mb-6">نظام تسجيل الحضور بـ QR Code</p>
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-sm text-slate-700 mb-1">البريد الجامعي</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
            />
          </div>
          <div>
            <label className="block text-sm text-slate-700 mb-1">كلمة المرور</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
            />
          </div>
          {error && <p className="text-sm text-red-600">{error}</p>}
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-brand-600 hover:bg-brand-700 text-white rounded-lg py-2.5 text-sm font-medium transition disabled:opacity-60"
          >
            {loading ? "جارٍ الدخول..." : "دخول"}
          </button>
        </form>
      </div>
    </div>
  );
}
