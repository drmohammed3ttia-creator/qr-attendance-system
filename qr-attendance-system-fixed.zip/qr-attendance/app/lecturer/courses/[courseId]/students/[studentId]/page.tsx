"use client";
import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";

type HistoryItem = {
  lectureId: string;
  lectureNumber: number;
  title: string;
  date: string;
  attended: boolean;
  scannedAt: string | null;
};

type DeviceStatus = { registered: boolean; registeredAt?: string };

export default function StudentHistoryPage() {
  const params = useParams<{ courseId: string; studentId: string }>();
  const router = useRouter();
  const [data, setData] = useState<{
    courseName: string;
    student: { fullName: string; universityId: string };
    present: number;
    total: number;
    attendancePct: number;
    history: HistoryItem[];
    device: DeviceStatus;
  } | null>(null);
  const [resetting, setResetting] = useState(false);
  const [resetMsg, setResetMsg] = useState<string | null>(null);

  function load() {
    fetch(`/api/courses/${params.courseId}/students/${params.studentId}`)
      .then((r) => r.json())
      .then(setData);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.courseId, params.studentId]);

  async function resetDevice() {
    if (!confirm("سيتم إلغاء ربط جهاز هذا الطالب الحالي، وسيتمكن من تسجيل جهاز جديد عند أول محاولة حضور تالية. متابعة؟")) {
      return;
    }
    setResetting(true);
    setResetMsg(null);
    const res = await fetch(
      `/api/courses/${params.courseId}/students/${params.studentId}/device/reset`,
      { method: "POST" }
    );
    setResetting(false);
    if (res.ok) {
      setResetMsg("تم إعادة تعيين الجهاز بنجاح.");
      load();
    } else {
      const d = await res.json().catch(() => ({}));
      setResetMsg(d.error || "تعذّرت إعادة التعيين");
    }
  }

  if (!data) {
    return <div className="min-h-screen bg-slate-50 flex items-center justify-center text-slate-400">جارٍ التحميل...</div>;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 px-6 py-4">
        <button onClick={() => router.back()} className="text-sm text-slate-500">← رجوع</button>
      </header>

      <main className="max-w-2xl mx-auto px-6 py-8">
        <p className="text-xs text-slate-400 mb-1">{data.courseName}</p>
        <h1 className="text-xl font-semibold text-slate-900 mb-1">{data.student.fullName}</h1>
        <p className="text-sm text-slate-500 mb-6">{data.student.universityId}</p>

        <div className="bg-white border border-slate-200 rounded-xl p-4 mb-6 flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-slate-900">
              {data.device.registered ? "الجهاز مسجَّل ومربوط بالحساب" : "لم يُسجِّل الطالب أي جهاز بعد"}
            </p>
            {data.device.registered && data.device.registeredAt && (
              <p className="text-xs text-slate-400 mt-1">
                أول تسجيل: {new Date(data.device.registeredAt).toLocaleString("ar-EG")}
              </p>
            )}
            {resetMsg && <p className="text-xs text-brand-700 mt-1">{resetMsg}</p>}
          </div>
          {data.device.registered && (
            <button
              onClick={resetDevice}
              disabled={resetting}
              className="text-sm bg-red-50 hover:bg-red-100 text-red-700 rounded-lg px-4 py-2 font-medium transition disabled:opacity-60 print:hidden"
            >
              {resetting ? "جارٍ الإعادة..." : "إعادة تعيين الجهاز"}
            </button>
          )}
        </div>

        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="bg-white border border-slate-200 rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-slate-900">{data.present}</p>
            <p className="text-xs text-slate-400 mt-1">حاضر</p>
          </div>
          <div className="bg-white border border-slate-200 rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-slate-900">{data.total - data.present}</p>
            <p className="text-xs text-slate-400 mt-1">غائب</p>
          </div>
          <div className="bg-white border border-slate-200 rounded-xl p-4 text-center">
            <p className={`text-2xl font-bold ${data.attendancePct < 75 ? "text-red-600" : "text-green-700"}`}>
              {data.attendancePct}%
            </p>
            <p className="text-xs text-slate-400 mt-1">نسبة الحضور</p>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500">
              <tr>
                <th className="text-right px-4 py-2">المحاضرة</th>
                <th className="text-right px-4 py-2">التاريخ</th>
                <th className="text-right px-4 py-2">الحالة</th>
                <th className="text-right px-4 py-2">وقت التسجيل</th>
              </tr>
            </thead>
            <tbody>
              {data.history.map((h) => (
                <tr key={h.lectureId} className="border-t border-slate-100">
                  <td className="px-4 py-2">محاضرة {h.lectureNumber} — {h.title}</td>
                  <td className="px-4 py-2">{new Date(h.date).toLocaleDateString("ar-EG")}</td>
                  <td className="px-4 py-2">
                    {h.attended ? (
                      <span className="text-green-700 font-medium">حاضر ✓</span>
                    ) : (
                      <span className="text-red-600 font-medium">غائب</span>
                    )}
                  </td>
                  <td className="px-4 py-2 text-slate-500">
                    {h.scannedAt ? new Date(h.scannedAt).toLocaleTimeString("ar-EG") : "—"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}
