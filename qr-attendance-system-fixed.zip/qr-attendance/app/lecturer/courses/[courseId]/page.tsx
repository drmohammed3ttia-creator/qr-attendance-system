"use client";
import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import Papa from "papaparse";

type Lecture = {
  id: string;
  lecture_number: number;
  title: string;
  lecture_date: string;
  allowed_duration_minutes: number;
};

type StudentStat = {
  studentId: string;
  universityId: string;
  fullName: string;
  present: number;
  absent: number;
  attendancePct: number;
};

export default function CourseDetailPage() {
  const params = useParams<{ courseId: string }>();
  const router = useRouter();
  const [tab, setTab] = useState<"lectures" | "students">("lectures");

  const [lectures, setLectures] = useState<Lecture[]>([]);
  const [showLectureForm, setShowLectureForm] = useState(false);
  const [lectureNumber, setLectureNumber] = useState(1);
  const [title, setTitle] = useState("");
  const [lectureDate, setLectureDate] = useState("");
  const [duration, setDuration] = useState(15);

  const [stats, setStats] = useState<{ totalLectures: number; students: StudentStat[] } | null>(
    null
  );
  const [uploadMsg, setUploadMsg] = useState<string | null>(null);

  async function loadLectures() {
    const res = await fetch(`/api/lectures?courseId=${params.courseId}`);
    if (res.ok) setLectures(await res.json());
  }
  async function loadStats() {
    const res = await fetch(`/api/courses/${params.courseId}/stats`);
    if (res.ok) setStats(await res.json());
  }

  useEffect(() => {
    loadLectures();
    loadStats();
  }, [params.courseId]);

  async function createLecture(e: React.FormEvent) {
    e.preventDefault();
    const res = await fetch("/api/lectures", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        courseId: params.courseId,
        lectureNumber,
        title,
        lectureDate,
        startTime: new Date(lectureDate).toISOString(),
        allowedDurationMinutes: duration,
      }),
    });
    if (res.ok) {
      setShowLectureForm(false);
      setTitle("");
      loadLectures();
    }
  }

  function handleCsvUpload(file: File) {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: async (results) => {
        // يتوقع أعمدة: universityId, fullName, email
        const students = results.data as any[];
        const res = await fetch("/api/students/upload", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ courseId: params.courseId, students }),
        });
        const data = await res.json();
        if (res.ok) {
          const okCount = data.results.filter((r: any) => r.status === "enrolled").length;
          setUploadMsg(`تم تسجيل ${okCount} من ${data.results.length} طالب بنجاح`);
          loadStats();
        } else {
          setUploadMsg(data.error || "فشل الرفع");
        }
      },
    });
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 px-6 py-4">
        <button onClick={() => router.push("/lecturer/dashboard")} className="text-sm text-slate-500">
          ← رجوع للمقررات
        </button>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-8">
        <div className="flex gap-2 mb-6 print:hidden">
          <button
            onClick={() => setTab("lectures")}
            className={`px-4 py-2 text-sm rounded-lg ${tab === "lectures" ? "bg-slate-900 text-white" : "bg-white border border-slate-200"}`}
          >
            المحاضرات
          </button>
          <button
            onClick={() => setTab("students")}
            className={`px-4 py-2 text-sm rounded-lg ${tab === "students" ? "bg-slate-900 text-white" : "bg-white border border-slate-200"}`}
          >
            الطلاب والحضور
          </button>
        </div>

        {tab === "lectures" && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold text-slate-900">المحاضرات</h2>
              <button
                onClick={() => setShowLectureForm((v) => !v)}
                className="bg-brand-600 hover:bg-brand-700 text-white rounded-lg px-4 py-2 text-sm font-medium"
              >
                + محاضرة جديدة
              </button>
            </div>

            {showLectureForm && (
              <form onSubmit={createLecture} className="bg-white border border-slate-200 rounded-xl p-5 mb-6 grid sm:grid-cols-2 gap-3">
                <input required type="number" placeholder="رقم المحاضرة" value={lectureNumber}
                  onChange={(e) => setLectureNumber(Number(e.target.value))}
                  className="rounded-lg border border-slate-300 px-3 py-2 text-sm" />
                <input required placeholder="عنوان المحاضرة" value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="rounded-lg border border-slate-300 px-3 py-2 text-sm" />
                <input required type="datetime-local" value={lectureDate}
                  onChange={(e) => setLectureDate(e.target.value)}
                  className="rounded-lg border border-slate-300 px-3 py-2 text-sm" />
                <input required type="number" placeholder="مدة السماح (دقائق)" value={duration}
                  onChange={(e) => setDuration(Number(e.target.value))}
                  className="rounded-lg border border-slate-300 px-3 py-2 text-sm" />
                <button className="sm:col-span-2 bg-slate-900 text-white rounded-lg py-2 text-sm font-medium">
                  حفظ المحاضرة
                </button>
              </form>
            )}

            <div className="space-y-2">
              {lectures.map((l) => (
                <div key={l.id} className="bg-white border border-slate-200 rounded-xl p-4 flex items-center justify-between">
                  <div>
                    <p className="font-medium text-slate-900">محاضرة {l.lecture_number} — {l.title}</p>
                    <p className="text-xs text-slate-400">{new Date(l.lecture_date).toLocaleDateString("ar-EG")}</p>
                  </div>
                  <button
                    onClick={() => router.push(`/lecturer/lecture/${l.id}`)}
                    className="bg-brand-600 hover:bg-brand-700 text-white rounded-lg px-4 py-2 text-sm font-medium"
                  >
                    Start Attendance
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === "students" && (
          <div>
            <div className="bg-white border border-slate-200 rounded-xl p-5 mb-6">
              <p className="text-sm font-medium text-slate-900 mb-2">رفع قائمة الطلاب (CSV)</p>
              <p className="text-xs text-slate-400 mb-3">الأعمدة المطلوبة: universityId, fullName, email</p>
              <input
                type="file"
                accept=".csv"
                onChange={(e) => e.target.files?.[0] && handleCsvUpload(e.target.files[0])}
                className="text-sm"
              />
              {uploadMsg && <p className="text-sm text-brand-700 mt-2">{uploadMsg}</p>}
            </div>

            <div className="flex items-center justify-between mb-3 print:hidden">
              <h2 className="font-semibold text-slate-900">نسب الحضور</h2>
              <div className="flex gap-4">
                <a
                  href={`/api/reports/export?courseId=${params.courseId}&format=csv`}
                  className="text-sm text-brand-700 hover:underline"
                >
                  تصدير CSV
                </a>
                <a
                  href={`/api/reports/export?courseId=${params.courseId}&format=xlsx`}
                  className="text-sm text-brand-700 hover:underline"
                >
                  تصدير Excel
                </a>
                <button onClick={() => window.print()} className="text-sm text-brand-700 hover:underline">
                  طباعة كشف الحضور
                </button>
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-slate-50 text-slate-500">
                  <tr>
                    <th className="text-right px-4 py-2">Student ID</th>
                    <th className="text-right px-4 py-2">الاسم</th>
                    <th className="text-right px-4 py-2">حضور</th>
                    <th className="text-right px-4 py-2">غياب</th>
                    <th className="text-right px-4 py-2">النسبة</th>
                  </tr>
                </thead>
                <tbody>
                  {stats?.students.map((s) => (
                    <tr key={s.studentId} className="border-t border-slate-100">
                      <td className="px-4 py-2">{s.universityId}</td>
                      <td className="px-4 py-2">
                        <Link
                          href={`/lecturer/courses/${params.courseId}/students/${s.studentId}`}
                          className="text-brand-700 hover:underline print:no-underline print:text-slate-900"
                        >
                          {s.fullName}
                        </Link>
                      </td>
                      <td className="px-4 py-2">{s.present}</td>
                      <td className="px-4 py-2">{s.absent}</td>
                      <td className="px-4 py-2">
                        <span className={s.attendancePct < 75 ? "text-red-600 font-medium" : "text-green-700"}>
                          {s.attendancePct}%
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
