"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";

type Course = { id: string; course_code: string; course_name: string };

export default function LecturerDashboard() {
  const router = useRouter();
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [courseCode, setCourseCode] = useState("");
  const [courseName, setCourseName] = useState("");

  async function loadCourses() {
    setLoading(true);
    const res = await fetch("/api/courses");
    if (res.status === 401) {
      router.push("/lecturer/login");
      return;
    }
    const data = await res.json();
    setCourses(data);
    setLoading(false);
  }

  useEffect(() => {
    loadCourses();
  }, []);

  async function createCourse(e: React.FormEvent) {
    e.preventDefault();
    const res = await fetch("/api/courses", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ courseCode, courseName }),
    });
    if (res.ok) {
      setCourseCode("");
      setCourseName("");
      setShowForm(false);
      loadCourses();
    }
  }

  async function logout() {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push("/lecturer/login");
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between">
        <h1 className="font-semibold text-slate-900">لوحة عضو هيئة التدريس</h1>
        <button onClick={logout} className="text-sm text-slate-500 hover:text-slate-800">
          تسجيل الخروج
        </button>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold text-slate-900">مقرراتي</h2>
          <button
            onClick={() => setShowForm((v) => !v)}
            className="bg-brand-600 hover:bg-brand-700 text-white rounded-lg px-4 py-2 text-sm font-medium transition"
          >
            + مقرر جديد
          </button>
        </div>

        {showForm && (
          <form
            onSubmit={createCourse}
            className="bg-white border border-slate-200 rounded-xl p-5 mb-6 flex gap-3 items-end"
          >
            <div className="flex-1">
              <label className="block text-sm text-slate-700 mb-1">رمز المقرر</label>
              <input
                required
                value={courseCode}
                onChange={(e) => setCourseCode(e.target.value)}
                placeholder="CS301"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
            <div className="flex-1">
              <label className="block text-sm text-slate-700 mb-1">اسم المقرر</label>
              <input
                required
                value={courseName}
                onChange={(e) => setCourseName(e.target.value)}
                placeholder="هياكل البيانات"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
            <button className="bg-slate-900 text-white rounded-lg px-4 py-2 text-sm font-medium">
              حفظ
            </button>
          </form>
        )}

        {loading ? (
          <p className="text-slate-400 text-sm">جارٍ التحميل...</p>
        ) : courses.length === 0 ? (
          <p className="text-slate-400 text-sm">لا توجد مقررات بعد.</p>
        ) : (
          <div className="grid sm:grid-cols-2 gap-4">
            {courses.map((c) => (
              <Link
                key={c.id}
                href={`/lecturer/courses/${c.id}`}
                className="bg-white border border-slate-200 rounded-xl p-5 hover:shadow-md transition"
              >
                <p className="text-xs text-slate-400 mb-1">{c.course_code}</p>
                <p className="font-semibold text-slate-900">{c.course_name}</p>
              </Link>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
