"use client";
import { useEffect, useRef, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import QRCode from "qrcode";

type LectureInfo = {
  courseName: string;
  lectureNumber: number;
  title: string;
};

export default function LiveLecturePage() {
  const params = useParams<{ lectureId: string }>();
  const router = useRouter();
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [qrDataUrl, setQrDataUrl] = useState<string | null>(null);
  const [secondsRemaining, setSecondsRemaining] = useState(25);
  const [presentCount, setPresentCount] = useState(0);
  const [lectureInfo, setLectureInfo] = useState<LectureInfo | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [stopped, setStopped] = useState(false);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  async function startSession(force = false) {
    setError(null);
    setStopped(false);
    const res = await fetch("/api/lectures/start", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ lectureId: params.lectureId, force }),
    });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error || "تعذر بدء الجلسة");
      return;
    }
    setSessionId(data.sessionId);
  }

  // بدء الجلسة عند تحميل الصفحة (تُستأنف تلقائيًا إن كانت هناك جلسة مفتوحة سارية)
  useEffect(() => {
    startSession(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.lectureId]);

  // تحديث دوري لرمز QR وعدد الحضور وبيانات المحاضرة — كل ثانيتين، بدون إعادة تحميل الصفحة
  useEffect(() => {
    if (!sessionId) return;

    async function tick() {
      const res = await fetch(`/api/qr/token?sessionId=${sessionId}`);
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setError(data.error || "انتهت الجلسة");
        if (pollRef.current) clearInterval(pollRef.current);
        return;
      }
      const data = await res.json();
      setSecondsRemaining(data.secondsRemaining);
      setPresentCount(data.presentCount);
      setLectureInfo({
        courseName: data.courseName,
        lectureNumber: data.lectureNumber,
        title: data.lectureTitle,
      });
      const dataUrl = await QRCode.toDataURL(data.qrPayload, { width: 480, margin: 1 });
      setQrDataUrl(dataUrl);
    }

    tick();
    pollRef.current = setInterval(tick, 2000);
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, [sessionId]);

  async function stopSession() {
    if (!sessionId) return;
    await fetch("/api/lectures/stop", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sessionId }),
    });
    if (pollRef.current) clearInterval(pollRef.current);
    setStopped(true);
    setQrDataUrl(null);
  }

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col items-center justify-center px-6 py-10">
      <button
        onClick={() => router.back()}
        className="absolute top-6 right-6 text-sm text-slate-400 hover:text-white"
      >
        ← رجوع
      </button>

      {lectureInfo && (
        <div className="text-center mb-4">
          <p className="text-lg text-slate-300">{lectureInfo.courseName}</p>
          <h1 className="text-2xl font-semibold">
            محاضرة {lectureInfo.lectureNumber} — {lectureInfo.title}
          </h1>
        </div>
      )}

      {error ? (
        <div className="text-center">
          <p className="text-red-400 text-lg mb-4">{error}</p>
          <button
            onClick={() => startSession(true)}
            className="bg-brand-600 hover:bg-brand-700 rounded-lg px-6 py-2.5 text-sm font-medium transition"
          >
            بدء جلسة جديدة
          </button>
        </div>
      ) : stopped ? (
        <div className="text-center">
          <p className="text-lg text-slate-300 mb-2">تم إيقاف تسجيل الحضور</p>
          <p className="text-sm text-slate-500 mb-6">
            سجّل {presentCount} طالب حضورهم في هذه المحاضرة
          </p>
          <button
            onClick={() => startSession(true)}
            className="bg-brand-600 hover:bg-brand-700 rounded-lg px-6 py-2.5 text-sm font-medium transition"
          >
            إعادة فتح تسجيل الحضور
          </button>
        </div>
      ) : qrDataUrl ? (
        <>
          <div className="bg-white p-6 rounded-3xl shadow-2xl">
            <img src={qrDataUrl} alt="QR Code" width={420} height={420} />
          </div>
          <div className="mt-6 flex items-center gap-8 text-center">
            <div>
              <p className="text-sm text-slate-400">يتجدد خلال</p>
              <p className="text-3xl font-bold tabular-nums">{secondsRemaining}s</p>
            </div>
            <div>
              <p className="text-sm text-slate-400">عدد الحاضرين الآن</p>
              <p className="text-3xl font-bold tabular-nums">{presentCount}</p>
            </div>
          </div>
          <button
            onClick={stopSession}
            className="mt-10 bg-red-600 hover:bg-red-700 rounded-lg px-6 py-2.5 text-sm font-medium transition"
          >
            إيقاف تسجيل الحضور
          </button>
        </>
      ) : (
        <p className="text-slate-400">جارٍ تجهيز رمز QR...</p>
      )}
    </div>
  );
}
