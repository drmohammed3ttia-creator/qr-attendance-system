import { NextRequest, NextResponse } from "next/server";
import { createServerSupabase } from "@/lib/supabase/server";

export async function POST(req: NextRequest) {
  const supabase = createServerSupabase();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { courseCode, courseName } = await req.json();
  if (!courseCode || !courseName) {
    return NextResponse.json({ error: "يجب إدخال رمز واسم المقرر" }, { status: 400 });
  }

  // RLS policy "lecturer manages own courses" تفرض lecturer_id = auth.uid() تلقائيًا
  const { data, error } = await supabase
    .from("courses")
    .insert({ course_code: courseCode, course_name: courseName, lecturer_id: user.id })
    .select()
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json(data);
}

export async function GET() {
  const supabase = createServerSupabase();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { data, error } = await supabase
    .from("courses")
    .select("*")
    .eq("lecturer_id", user.id)
    .order("created_at", { ascending: false });

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json(data);
}
