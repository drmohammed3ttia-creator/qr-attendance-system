import { NextRequest, NextResponse } from "next/server";
import { createServerSupabase } from "@/lib/supabase/server";

export async function GET(
  req: NextRequest,
  { params }: { params: { courseId: string } }
) {
  const supabase = createServerSupabase();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const courseId = params.courseId;
  const { data: course } = await supabase
    .from("courses")
    .select("id")
    .eq("id", courseId)
    .eq("lecturer_id", user.id)
    .maybeSingle();
  if (!course) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { data: lectures } = await supabase
    .from("lectures")
    .select("id")
    .eq("course_id", courseId);
  const lectureIds = (lectures ?? []).map((l) => l.id);
  const totalLectures = lectureIds.length;

  const { data: enrollments } = await supabase
    .from("enrollments")
    .select("student_id, users_profile!inner(university_id, full_name)")
    .eq("course_id", courseId);

  const { data: sessions } = await supabase
    .from("attendance_sessions")
    .select("id")
    .in("lecture_id", lectureIds.length ? lectureIds : ["00000000-0000-0000-0000-000000000000"]);
  const sessionIds = (sessions ?? []).map((s) => s.id);

  const { data: records } = await supabase
    .from("attendance_records")
    .select("student_id")
    .in("session_id", sessionIds.length ? sessionIds : ["00000000-0000-0000-0000-000000000000"]);

  const presentCountByStudent = new Map<string, number>();
  for (const r of records ?? []) {
    presentCountByStudent.set(r.student_id, (presentCountByStudent.get(r.student_id) ?? 0) + 1);
  }

  const students = (enrollments ?? []).map((e: any) => {
    const present = presentCountByStudent.get(e.student_id) ?? 0;
    const absent = Math.max(totalLectures - present, 0);
    const pct = totalLectures > 0 ? Math.round((present / totalLectures) * 1000) / 10 : 0;
    return {
      studentId: e.student_id,
      universityId: e.users_profile.university_id,
      fullName: e.users_profile.full_name,
      present,
      absent,
      attendancePct: pct,
    };
  });

  return NextResponse.json({ totalLectures, students });
}
