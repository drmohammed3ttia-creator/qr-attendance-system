import { NextRequest, NextResponse } from "next/server";
import { createServerSupabase, createServiceSupabase } from "@/lib/supabase/server";

// POST /api/courses/:courseId/students/:studentId/device/reset
//
// يُستخدم فقط من قِبل الدكتور صاحب المقرر لإعادة تعيين الجهاز المسجَّل
// لطالب معيّن (مثلاً غيّر هاتفه أو فقده). بعد النجاح يستطيع الطالب تسجيل
// جهاز جديد تلقائيًا عند أول محاولة حضور تالية (نفس منطق أول استخدام).
//
// الطالب نفسه لا يملك أي وصول لهذا المسار: 1) يتطلب أن يكون طالب هذا
// المقرر ضمن قائمة enrollments الخاصة بالدكتور المسجَّل دخوله فعليًا،
// و2) لا توجد أي policy تسمح بوصول العميل مباشرة لجدول student_devices
// (RLS بدون policy = رفض افتراضي)، فحتى لو حاول الطالب استدعاء نفس
// الرابط لن يجتاز فحص "lecturer_id = auth.uid()" على المقرر.
export async function POST(
  req: NextRequest,
  { params }: { params: { courseId: string; studentId: string } }
) {
  const supabase = createServerSupabase();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { courseId, studentId } = params;

  // التحقق أن الدكتور فعلاً صاحب هذا المقرر (وليس أي مستخدم مسجّل دخول فقط)
  const { data: course } = await supabase
    .from("courses")
    .select("id")
    .eq("id", courseId)
    .eq("lecturer_id", user.id)
    .maybeSingle();
  if (!course) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  // التحقق أن الطالب مسجَّل فعليًا في هذا المقرر تحديدًا (وليس أي طالب في النظام)
  const { data: enrollment } = await supabase
    .from("enrollments")
    .select("id")
    .eq("course_id", courseId)
    .eq("student_id", studentId)
    .maybeSingle();
  if (!enrollment) {
    return NextResponse.json({ error: "Student is not enrolled in this course" }, { status: 404 });
  }

  const service = createServiceSupabase();

  const { error: deleteErr } = await service
    .from("student_devices")
    .delete()
    .eq("student_id", studentId);

  if (deleteErr) {
    return NextResponse.json({ error: deleteErr.message }, { status: 500 });
  }

  // سجل تدقيق: من أعاد التعيين ومتى (لا يفشل الطلب لو تعذّر تسجيل السجل)
  await service.from("device_reset_log").insert({ student_id: studentId, reset_by: user.id });

  return NextResponse.json({ ok: true });
}
