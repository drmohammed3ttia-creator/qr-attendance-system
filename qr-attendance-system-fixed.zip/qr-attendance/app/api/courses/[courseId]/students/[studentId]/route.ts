import { NextRequest, NextResponse } from "next/server";
import { createServerSupabase, createServiceSupabase } from "@/lib/supabase/server";

export async function GET(
  req: NextRequest,
  { params }: { params: { courseId: string; studentId: string } }
) {
  const supabase = createServerSupabase();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { courseId, studentId } = params;

  // التحقق أن الدكتور فعلاً صاحب هذا المقرر
  const { data: course } = await supabase
    .from("courses")
    .select("id, course_name")
    .eq("id", courseId)
    .eq("lecturer_id", user.id)
    .maybeSingle();
  if (!course) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { data: student } = await supabase
    .from("users_profile")
    .select("id, full_name, university_id")
    .eq("id", studentId)
    .maybeSingle();
  if (!student) return NextResponse.json({ error: "Student not found" }, { status: 404 });

  // كل محاضرات المقرر
  const { data: lectures } = await supabase
    .from("lectures")
    .select("id, lecture_number, title, lecture_date")
    .eq("course_id", courseId)
    .order("lecture_number", { ascending: true });

  const lectureIds = (lectures ?? []).map((l) => l.id);

  // جلسات هذه المحاضرات (قد تكون أكثر من جلسة لو أعاد الدكتور الفتح)
  const { data: sessions } = await supabase
    .from("attendance_sessions")
    .select("id, lecture_id")
    .in("lecture_id", lectureIds.length ? lectureIds : ["00000000-0000-0000-0000-000000000000"]);

  const sessionToLecture = new Map((sessions ?? []).map((s) => [s.id, s.lecture_id]));
  const sessionIds = (sessions ?? []).map((s) => s.id);

  // سجلات حضور هذا الطالب فقط ضمن هذه الجلسات
  const { data: records } = await supabase
    .from("attendance_records")
    .select("session_id, scanned_at")
    .eq("student_id", studentId)
    .in("session_id", sessionIds.length ? sessionIds : ["00000000-0000-0000-0000-000000000000"]);

  const attendedLectureIds = new Set(
    (records ?? []).map((r) => sessionToLecture.get(r.session_id)).filter(Boolean)
  );
  const scannedAtByLecture = new Map<string, string>();
  for (const r of records ?? []) {
    const lecId = sessionToLecture.get(r.session_id);
    if (lecId) scannedAtByLecture.set(lecId, r.scanned_at);
  }

  const history = (lectures ?? []).map((l) => ({
    lectureId: l.id,
    lectureNumber: l.lecture_number,
    title: l.title,
    date: l.lecture_date,
    attended: attendedLectureIds.has(l.id),
    scannedAt: scannedAtByLecture.get(l.id) ?? null,
  }));

  const present = history.filter((h) => h.attended).length;
  const total = history.length;

  // حالة ربط الجهاز — student_devices ليس له أي RLS policy للعميل عمدًا،
  // لذا نقرأه هنا عبر Service Role بعد أن تحققنا فعليًا أعلاه أن طالب
  // الطلب دكتور يملك هذا المقرر
  const service = createServiceSupabase();
  const { data: device } = await service
    .from("student_devices")
    .select("registered_at")
    .eq("student_id", studentId)
    .maybeSingle();

  return NextResponse.json({
    courseName: course.course_name,
    student: { fullName: student.full_name, universityId: student.university_id },
    present,
    total,
    attendancePct: total > 0 ? Math.round((present / total) * 1000) / 10 : 0,
    history,
    device: device ? { registered: true, registeredAt: device.registered_at } : { registered: false },
  });
}
