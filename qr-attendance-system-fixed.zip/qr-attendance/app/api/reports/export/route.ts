import { NextRequest, NextResponse } from "next/server";
import { createServerSupabase } from "@/lib/supabase/server";
import * as XLSX from "xlsx";

// GET /api/reports/export?courseId=...&from=YYYY-MM-DD&to=YYYY-MM-DD&format=csv|xlsx
// يرجع تقرير حضور بصيغة CSV أو Excel: Student ID, Student Name, Present, Absent, Attendance %
export async function GET(req: NextRequest) {
  const supabase = createServerSupabase();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const courseId = req.nextUrl.searchParams.get("courseId");
  if (!courseId) return NextResponse.json({ error: "courseId is required" }, { status: 400 });

  const format = req.nextUrl.searchParams.get("format") === "xlsx" ? "xlsx" : "csv";

  const { data: course } = await supabase
    .from("courses")
    .select("id, course_name, course_code")
    .eq("id", courseId)
    .eq("lecturer_id", user.id)
    .maybeSingle();
  if (!course) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const from = req.nextUrl.searchParams.get("from");
  const to = req.nextUrl.searchParams.get("to");

  let lecturesQuery = supabase
    .from("lectures")
    .select("id, lecture_number, lecture_date")
    .eq("course_id", courseId);
  if (from) lecturesQuery = lecturesQuery.gte("lecture_date", from);
  if (to) lecturesQuery = lecturesQuery.lte("lecture_date", to);
  const { data: lectures } = await lecturesQuery;
  const lectureIds = (lectures ?? []).map((l) => l.id);
  const totalLectures = lectureIds.length;

  const { data: enrollments } = await supabase
    .from("enrollments")
    .select("student_id, users_profile!inner(university_id, full_name)")
    .eq("course_id", courseId);

  const { data: sessions } = await supabase
    .from("attendance_sessions")
    .select("id, lecture_id")
    .in("lecture_id", lectureIds.length ? lectureIds : ["00000000-0000-0000-0000-000000000000"]);

  const sessionIds = (sessions ?? []).map((s) => s.id);
  const { data: records } = await supabase
    .from("attendance_records")
    .select("student_id, session_id")
    .in("session_id", sessionIds.length ? sessionIds : ["00000000-0000-0000-0000-000000000000"]);

  const presentByStudent = new Map<string, number>();
  for (const r of records ?? []) {
    presentByStudent.set(r.student_id, (presentByStudent.get(r.student_id) ?? 0) + 1);
  }

  const rows = (enrollments ?? []).map((e: any) => {
    const present = presentByStudent.get(e.student_id) ?? 0;
    const absent = Math.max(totalLectures - present, 0);
    const pct = totalLectures > 0 ? Number(((present / totalLectures) * 100).toFixed(1)) : 0;
    return {
      "Student ID": e.users_profile.university_id,
      "Student Name": e.users_profile.full_name,
      Present: present,
      Absent: absent,
      "Attendance %": pct,
    };
  });

  const fileBase = `attendance_${course.course_code}`;

  if (format === "xlsx") {
    const worksheet = XLSX.utils.json_to_sheet(rows);
    worksheet["!cols"] = [{ wch: 14 }, { wch: 28 }, { wch: 10 }, { wch: 10 }, { wch: 14 }];
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Attendance");
    const buffer = XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });

    return new NextResponse(buffer, {
      headers: {
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": `attachment; filename="${fileBase}.xlsx"`,
      },
    });
  }

  // إصلاح: كانت أسماء الطلاب تُلصق داخل علامتي اقتباس بدون تهريب أي علامة
  // اقتباس داخلية، فإذا احتوى الاسم على " كان يُنتج ملف CSV تالفًا (أعمدة
  // منزاحة). القاعدة القياسية لـ CSV: مضاعفة أي " داخل الحقل نفسه.
  const csvEscape = (value: string | number) => `"${String(value).replace(/"/g, '""')}"`;

  const csvLines = ["Student ID,Student Name,Present,Absent,Attendance %"];
  for (const r of rows) {
    csvLines.push(
      [
        csvEscape(r["Student ID"]),
        csvEscape(r["Student Name"]),
        r.Present,
        r.Absent,
        `${r["Attendance %"]}%`,
      ].join(",")
    );
  }
  return new NextResponse(csvLines.join("\n"), {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${fileBase}.csv"`,
    },
  });
}
