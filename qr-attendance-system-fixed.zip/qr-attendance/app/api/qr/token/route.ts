import { NextRequest, NextResponse } from "next/server";
import { createServerSupabase, createServiceSupabase } from "@/lib/supabase/server";
import { currentWindow, signWindow, buildQrPayload, QR_WINDOW_SECONDS } from "@/lib/qr";

// GET /api/qr/token?sessionId=...
// يُستدعى بشكل متكرر من صفحة عرض الـ QR على شاشة المحاضرة
export async function GET(req: NextRequest) {
  const supabase = createServerSupabase();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const sessionId = req.nextUrl.searchParams.get("sessionId");
  if (!sessionId) {
    return NextResponse.json({ error: "sessionId is required" }, { status: 400 });
  }

  const { data: session, error } = await supabase
    .from("attendance_sessions")
    .select(
      "id, status, closes_at, secret_key, lectures!inner(lecture_number, title, course_id, courses!inner(lecturer_id, course_name))"
    )
    .eq("id", sessionId)
    .single();

  if (error || !session) {
    return NextResponse.json({ error: "Session not found" }, { status: 404 });
  }
  // @ts-ignore
  if (session.lectures.courses.lecturer_id !== user.id) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  if (session.status !== "open" || new Date(session.closes_at) < new Date()) {
    return NextResponse.json({ error: "Session closed" }, { status: 410 });
  }

  const service = createServiceSupabase();
  const { count } = await service
    .from("attendance_records")
    .select("id", { count: "exact", head: true })
    .eq("session_id", sessionId);

  const window = currentWindow();
  const signature = signWindow(session.secret_key, session.id, window);
  const baseUrl = process.env.NEXT_PUBLIC_APP_URL || req.nextUrl.origin;
  const qrPayload = buildQrPayload(baseUrl, session.id, window, signature);

  const secondsIntoWindow = Math.floor(Date.now() / 1000) % QR_WINDOW_SECONDS;
  const secondsRemaining = QR_WINDOW_SECONDS - secondsIntoWindow;

  return NextResponse.json({
    qrPayload,
    secondsRemaining,
    presentCount: count ?? 0,
    closesAt: session.closes_at,
    // @ts-ignore - nested relation from supabase-js
    courseName: session.lectures.courses.course_name,
    // @ts-ignore
    lectureNumber: session.lectures.lecture_number,
    // @ts-ignore
    lectureTitle: session.lectures.title,
  });
}
