import { NextRequest, NextResponse } from "next/server";
import { createServerSupabase, createServiceSupabase } from "@/lib/supabase/server";
import { verifyWindow } from "@/lib/qr";
import { rateLimit, cleanupRateLimitBuckets } from "@/lib/rate-limit";
import { hashDeviceId, isPlausibleDeviceId } from "@/lib/device";

// جميع التحققات هنا Server-side فقط. لا يوجد أي مسار آخر لإدراج
// صف في attendance_records (RLS يمنع أي INSERT مباشر من العميل).
export async function POST(req: NextRequest) {
  cleanupRateLimitBuckets();

  const supabase = createServerSupabase();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "يجب تسجيل الدخول أولاً" }, { status: 401 });
  }

  // حد أقصى 8 محاولات كل دقيقة لكل طالب — يمنع محاولات تخمين التوقيع
  // أو إعادة إرسال متكررة، مع ترك هامش كافٍ للاستخدام الطبيعي.
  // rateLimit أصبحت async (تدعم الآن Upstash Redis على الإنتاج — راجع lib/rate-limit.ts)
  const limit = await rateLimit(`confirm:${user.id}`, 8, 60_000);
  if (!limit.allowed) {
    return NextResponse.json(
      { error: "محاولات كثيرة جدًا، الرجاء الانتظار قليلاً والمحاولة مجددًا" },
      { status: 429 }
    );
  }

  const { sessionId, window, signature, gpsLat, gpsLng, deviceId } = await req.json();
  if (!sessionId || window === undefined || !signature) {
    return NextResponse.json({ error: "بيانات ناقصة" }, { status: 400 });
  }
  if (!isPlausibleDeviceId(deviceId)) {
    return NextResponse.json({ error: "معرّف الجهاز مفقود أو غير صالح" }, { status: 400 });
  }

  const service = createServiceSupabase();

  // 1) التأكد أن المستخدم طالب فعلاً
  const { data: profile } = await service
    .from("users_profile")
    .select("id, role, full_name")
    .eq("id", user.id)
    .single();

  if (!profile || profile.role !== "student") {
    return NextResponse.json({ error: "هذا الحساب غير مسجل كطالب" }, { status: 403 });
  }

  // 2) جلب الجلسة والتحقق أنها لا تزال مفتوحة وسارية زمنيًا
  const { data: session, error: sessionErr } = await service
    .from("attendance_sessions")
    .select(
      "id, status, closes_at, secret_key, require_gps, require_wifi, lecture_gps_lat, lecture_gps_lng, gps_radius_meters, lectures!inner(id, course_id, lecture_number, title)"
    )
    .eq("id", sessionId)
    .single();

  if (sessionErr || !session) {
    return NextResponse.json({ error: "جلسة الحضور غير موجودة" }, { status: 404 });
  }
  if (session.status !== "open") {
    return NextResponse.json({ error: "انتهى وقت تسجيل الحضور لهذه المحاضرة" }, { status: 410 });
  }
  if (new Date(session.closes_at) < new Date()) {
    return NextResponse.json({ error: "انتهت صلاحية جلسة الحضور" }, { status: 410 });
  }

  // 3) التحقق من توقيع QR (يمنع تصوير الكود وإرساله لاحقًا أو تزييفه)
  const verification = verifyWindow(session.secret_key, session.id, Number(window), signature);
  if (!verification.valid) {
    return NextResponse.json({ error: "رمز QR غير صالح أو منتهي الصلاحية، الرجاء إعادة المسح" }, { status: 401 });
  }

  // 4) التأكد أن الطالب مسجّل فعليًا في هذا المقرر
  // @ts-ignore
  const courseId = session.lectures.course_id;
  const { data: enrollment } = await service
    .from("enrollments")
    .select("id")
    .eq("course_id", courseId)
    .eq("student_id", user.id)
    .maybeSingle();

  if (!enrollment) {
    return NextResponse.json(
      { error: "أنت غير مسجل في هذا المقرر، لا يمكنك تسجيل الحضور" },
      { status: 403 }
    );
  }

  // 5) ربط "جهاز واحد لكل طالب" (device binding) — يمنع طالبًا من تسجيل
  // حضور طالب آخر باستخدام نفس الهاتف. القيد الفعلي المانع هو UNIQUE
  // constraint على student_devices.device_hash في القاعدة (راجع
  // supabase/schema.sql) — الكود هنا فقط يستدعيه ويترجم الخطأ لرسالة واضحة.
  const deviceHash = hashDeviceId(deviceId);

  const { data: existingDevice } = await service
    .from("student_devices")
    .select("device_hash")
    .eq("student_id", user.id)
    .maybeSingle();

  if (existingDevice) {
    // هذا الطالب سبق وسجّل جهازًا — يجب أن يطابق الجهاز الحالي، وإلا فهذا
    // يعني أنه يحاول تسجيل الحضور من جهاز مختلف عن جهازه المسجَّل
    if (existingDevice.device_hash !== deviceHash) {
      return NextResponse.json(
        {
          error:
            "حسابك مرتبط بجهاز آخر مسجَّل مسبقًا. استخدم نفس الجهاز، أو اطلب من الدكتور إعادة تعيين جهازك.",
        },
        { status: 403 }
      );
    }
  } else {
    // أول استخدام لهذا الطالب على الإطلاق — نربط جهازه الحالي تلقائيًا الآن
    const { error: deviceInsertErr } = await service
      .from("student_devices")
      .insert({ student_id: user.id, device_hash: deviceHash });

    if (deviceInsertErr) {
      if (deviceInsertErr.code === "23505") {
        // تعارض UNIQUE من القاعدة: إما..
        if (deviceInsertErr.message?.includes("student_devices_device_hash_key")) {
          // ..أن هذا الجهاز (device_hash) مرتبط بالفعل بحساب طالب آخر —
          // هذا بالضبط ما يمنع "طالب B يستخدم جهاز طالب A"
          return NextResponse.json(
            { error: "هذا الجهاز مسجَّل بالفعل لحساب طالب آخر ولا يمكن استخدامه لتسجيل حضورك." },
            { status: 403 }
          );
        }
        // ..أو أن Race condition حدث: طلب متزامن آخر لنفس الطالب سبق وسجّل
        // جهازًا (مثلاً نقرتان سريعتان من تبويبين). نعيد القراءة ونعامل
        // الأمر كأنه كان مسجَّلًا من البداية
        const { data: raceWinner } = await service
          .from("student_devices")
          .select("device_hash")
          .eq("student_id", user.id)
          .maybeSingle();
        if (!raceWinner || raceWinner.device_hash !== deviceHash) {
          return NextResponse.json(
            {
              error:
                "حسابك مرتبط بجهاز آخر مسجَّل مسبقًا. استخدم نفس الجهاز، أو اطلب من الدكتور إعادة تعيين جهازك.",
            },
            { status: 403 }
          );
        }
        // نفس الجهاز فاز في السباق — نكمل بشكل طبيعي
      } else {
        return NextResponse.json({ error: deviceInsertErr.message }, { status: 500 });
      }
    }
  }

  // 6) (اختياري) التحقق من الموقع الجغرافي إن كان مفعّلًا لهذه الجلسة
  if (session.require_gps) {
    if (gpsLat == null || gpsLng == null) {
      return NextResponse.json({ error: "يلزم تفعيل الموقع الجغرافي لتسجيل الحضور" }, { status: 400 });
    }
    const distance = haversineMeters(
      gpsLat,
      gpsLng,
      session.lecture_gps_lat!,
      session.lecture_gps_lng!
    );
    if (distance > (session.gps_radius_meters ?? 100)) {
      return NextResponse.json(
        { error: "يبدو أنك خارج نطاق قاعة المحاضرة" },
        { status: 403 }
      );
    }
  }

  // 7) منع التسجيل المكرر (يُفرض أيضًا بواسطة UNIQUE constraint في القاعدة كحماية إضافية)
  const { data: existing } = await service
    .from("attendance_records")
    .select("id")
    .eq("session_id", sessionId)
    .eq("student_id", user.id)
    .maybeSingle();

  if (existing) {
    return NextResponse.json({ error: "لقد سجّلت حضورك مسبقًا لهذه المحاضرة" }, { status: 409 });
  }

  // 8) تسجيل الحضور
  const ip =
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    req.headers.get("x-real-ip") ||
    null;
  const userAgent = req.headers.get("user-agent") || null;

  const { data: record, error: insertErr } = await service
    .from("attendance_records")
    .insert({
      session_id: sessionId,
      student_id: user.id,
      ip_address: ip,
      user_agent: userAgent,
      gps_lat: gpsLat ?? null,
      gps_lng: gpsLng ?? null,
    })
    .select("scanned_at")
    .single();

  if (insertErr) {
    // التقاط تعارض UNIQUE في حال Race condition (نقرتان متزامنتان)
    if (insertErr.code === "23505") {
      return NextResponse.json({ error: "لقد سجّلت حضورك مسبقًا لهذه المحاضرة" }, { status: 409 });
    }
    return NextResponse.json({ error: insertErr.message }, { status: 500 });
  }

  return NextResponse.json({
    ok: true,
    scannedAt: record.scanned_at,
    // @ts-ignore
    lectureTitle: session.lectures.title,
    // @ts-ignore
    lectureNumber: session.lectures.lecture_number,
  });
}

function haversineMeters(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 6371000;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
