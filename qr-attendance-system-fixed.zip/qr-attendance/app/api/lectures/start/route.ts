import { NextRequest, NextResponse } from "next/server";
import { createServerSupabase, createServiceSupabase } from "@/lib/supabase/server";
import { generateSecretKey } from "@/lib/qr";

export async function POST(req: NextRequest) {
  const supabase = createServerSupabase();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { lectureId, options, force } = await req.json();
  if (!lectureId) {
    return NextResponse.json({ error: "lectureId is required" }, { status: 400 });
  }

  // نتحقق أن المحاضرة تعود لمقرر يملكه هذا الدكتور فعليًا (وليس فقط أنه مسجّل دخول)
  const { data: lecture, error: lectureErr } = await supabase
    .from("lectures")
    .select("id, allowed_duration_minutes, course_id, courses!inner(lecturer_id)")
    .eq("id", lectureId)
    .single();

  if (lectureErr || !lecture) {
    return NextResponse.json({ error: "Lecture not found" }, { status: 404 });
  }
  // @ts-ignore - علاقة nested من supabase-js
  if (lecture.courses.lecturer_id !== user.id) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const service = createServiceSupabase();

  // إن كانت هناك جلسة مفتوحة وسارية بالفعل لهذه المحاضرة (مثلًا الدكتور عمل
  // Refresh للصفحة بالخطأ)، نعيد استخدامها بدلاً من تصفير عداد الحضور —
  // إلا إذا طُلب صراحةً force (إعادة بدء الجلسة من جديد).
  if (!force) {
    const { data: existing } = await service
      .from("attendance_sessions")
      .select("id, closes_at")
      .eq("lecture_id", lectureId)
      .eq("status", "open")
      .gt("closes_at", new Date().toISOString())
      .order("opened_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (existing) {
      return NextResponse.json({ sessionId: existing.id, closesAt: existing.closes_at, resumed: true });
    }
  }

  // نغلق أي جلسة سابقة منتهية/مفتوحة لنفس المحاضرة قبل إنشاء جلسة جديدة
  await service
    .from("attendance_sessions")
    .update({ status: "closed" })
    .eq("lecture_id", lectureId)
    .eq("status", "open");

  const secretKey = generateSecretKey();
  const durationMinutes = lecture.allowed_duration_minutes ?? 15;
  const closesAt = new Date(Date.now() + durationMinutes * 60_000).toISOString();

  const { data: session, error } = await service
    .from("attendance_sessions")
    .insert({
      lecture_id: lectureId,
      secret_key: secretKey,
      closes_at: closesAt,
      require_gps: options?.requireGps ?? false,
      require_wifi: options?.requireWifi ?? false,
      lecture_gps_lat: options?.gpsLat ?? null,
      lecture_gps_lng: options?.gpsLng ?? null,
      gps_radius_meters: options?.gpsRadius ?? 100,
      allowed_wifi_ssid: options?.wifiSsid ?? null,
    })
    .select("id, closes_at")
    .single();

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ sessionId: session.id, closesAt: session.closes_at });
}
