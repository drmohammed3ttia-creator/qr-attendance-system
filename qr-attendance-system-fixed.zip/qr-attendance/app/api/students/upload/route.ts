import { NextRequest, NextResponse } from "next/server";
import { createServerSupabase, createServiceSupabase } from "@/lib/supabase/server";

// يتوقع body: { courseId, students: [{ universityId, fullName, email }] }
// (تحويل ملف Excel/CSV إلى JSON يتم في الواجهة باستخدام مكتبة xlsx/papaparse قبل الإرسال)
//
// ملاحظة مهمة: هذا المسار "يُهيئ" حساب الطالب (دعوة عبر Supabase Auth) إن لم يكن
// موجودًا بعد، ثم يربطه بالمقرر عبر enrollments. الطالب يفعّل حسابه لاحقًا بأول تسجيل دخول.
export async function POST(req: NextRequest) {
  const supabase = createServerSupabase();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { courseId, students } = await req.json();
  if (!courseId || !Array.isArray(students) || students.length === 0) {
    return NextResponse.json({ error: "بيانات غير صحيحة" }, { status: 400 });
  }

  // التحقق من ملكية المقرر
  const { data: course } = await supabase
    .from("courses")
    .select("id")
    .eq("id", courseId)
    .eq("lecturer_id", user.id)
    .maybeSingle();

  if (!course) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const service = createServiceSupabase();
  const results: { universityId: string; status: string }[] = [];

  for (const s of students) {
    const email: string = s.email;
    const universityId: string = String(s.universityId || "").trim();
    const fullName: string = s.fullName || "";

    if (!email || !universityId) {
      results.push({ universityId, status: "skipped: missing email/id" });
      continue;
    }

    // إيجاد أو إنشاء المستخدم في auth.users
    let studentUserId: string | null = null;
    const { data: existingProfile } = await service
      .from("users_profile")
      .select("id")
      .eq("university_id", universityId)
      .maybeSingle();

    if (existingProfile) {
      studentUserId = existingProfile.id;
    } else {
      const appUrl = process.env.NEXT_PUBLIC_APP_URL || req.nextUrl.origin;
      const { data: invited, error: inviteErr } = await service.auth.admin.inviteUserByEmail(
        email,
        { redirectTo: `${appUrl}/student/login` }
      );
      if (inviteErr || !invited?.user) {
        results.push({ universityId, status: `error: ${inviteErr?.message}` });
        continue;
      }
      studentUserId = invited.user.id;
      await service.from("users_profile").insert({
        id: studentUserId,
        role: "student",
        full_name: fullName,
        university_id: universityId,
      });
    }

    const { error: enrollErr } = await service
      .from("enrollments")
      .upsert(
        { course_id: courseId, student_id: studentUserId! },
        { onConflict: "course_id,student_id" }
      );

    results.push({ universityId, status: enrollErr ? `error: ${enrollErr.message}` : "enrolled" });
  }

  return NextResponse.json({ results });
}
