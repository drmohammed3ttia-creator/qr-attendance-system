import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

export async function middleware(request: NextRequest) {
  const response = NextResponse.next({ request: { headers: request.headers } });

  // هذا الـ middleware لا يفرض تسجيل الدخول على أي مسار (الحماية الفعلية
  // تتم داخل كل صفحة عبر supabase.auth.getUser() على المتصفح)، هو فقط
  // يحاول تجديد كوكي الجلسة. لذلك أي فشل هنا يجب ألا يُسقط الطلب أبدًا —
  // إسقاط الطلب هنا كان يعطّل حتى الصفحات العامة مثل الرئيسية وتسجيل الدخول.

  if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
    console.error(
      "[middleware] NEXT_PUBLIC_SUPABASE_URL or NEXT_PUBLIC_SUPABASE_ANON_KEY is not set — skipping session refresh"
    );
    return response;
  }

  try {
    const supabase = createServerClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      cookies: {
        get(name: string) {
          return request.cookies.get(name)?.value;
        },
        set(name: string, value: string, options: any) {
          response.cookies.set({ name, value, ...options });
        },
        remove(name: string, options: any) {
          response.cookies.set({ name, value: "", ...options });
        },
      },
    });

    // يجدد الـ session cookie تلقائيًا إن كانت قريبة من الانتهاء
    await supabase.auth.getUser();
  } catch (err) {
    // كوكي تالف، أو Supabase غير متاح مؤقتًا، أو أي خطأ شبكة — لا نُسقط
    // الطلب، فقط نمرره كما هو دون تجديد الجلسة
    console.error("[middleware] Supabase session refresh failed:", err);
  }

  return response;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
