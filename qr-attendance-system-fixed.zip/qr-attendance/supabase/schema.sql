-- ============================================================
-- QR Attendance System — Database Schema (PostgreSQL / Supabase)
-- ============================================================
-- ملاحظة: Supabase توفر جدول auth.users تلقائيًا (Authentication).
-- نربط أعضاء هيئة التدريس والطلاب بهذا الجدول عبر user_id.

create extension if not exists "pgcrypto";

-- ---------------------------------------------------------
-- 1) users_profile : يوسّع auth.users بمعلومات الدور (role)
-- ---------------------------------------------------------
create type user_role as enum ('lecturer', 'student');

create table users_profile (
  id uuid primary key references auth.users(id) on delete cascade,
  role user_role not null,
  full_name text not null,
  university_id text unique,        -- الرقم الجامعي (للطالب) أو الرقم الوظيفي (للدكتور)
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------
-- 2) courses : المقررات
-- ---------------------------------------------------------
create table courses (
  id uuid primary key default gen_random_uuid(),
  lecturer_id uuid not null references users_profile(id) on delete cascade,
  course_code text not null,          -- مثال: CS301
  course_name text not null,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------
-- 3) enrollments : تسجيل الطلاب في المقررات (Many-to-Many)
-- ---------------------------------------------------------
create table enrollments (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references courses(id) on delete cascade,
  student_id uuid not null references users_profile(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (course_id, student_id)
);

-- ---------------------------------------------------------
-- 4) lectures : كل محاضرة داخل مقرر
-- ---------------------------------------------------------
create table lectures (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references courses(id) on delete cascade,
  lecture_number int not null,
  title text not null,
  lecture_date date not null,
  start_time timestamptz not null,
  allowed_duration_minutes int not null default 15, -- مدة السماح بتسجيل الحضور
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------
-- 5) attendance_sessions : جلسة تفعيل الحضور (يبدأها الدكتور بضغطة Start)
-- ---------------------------------------------------------
create type session_status as enum ('open', 'closed');

create table attendance_sessions (
  id uuid primary key default gen_random_uuid(),   -- Attendance Session ID
  lecture_id uuid not null references lectures(id) on delete cascade,
  status session_status not null default 'open',
  secret_key text not null,       -- سر عشوائي فريد لكل جلسة، يُستخدم في توقيع الـ QR Token (HMAC)
  opened_at timestamptz not null default now(),
  closes_at timestamptz not null, -- opened_at + allowed_duration_minutes
  require_gps boolean not null default false,
  require_wifi boolean not null default false,
  lecture_gps_lat double precision,
  lecture_gps_lng double precision,
  gps_radius_meters int default 100,
  allowed_wifi_ssid text
);

-- ---------------------------------------------------------
-- 6) attendance_records : سجل حضور كل طالب لكل جلسة
-- ---------------------------------------------------------
create table attendance_records (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references attendance_sessions(id) on delete cascade,
  student_id uuid not null references users_profile(id) on delete cascade,
  scanned_at timestamptz not null default now(),
  ip_address text,
  user_agent text,
  gps_lat double precision,
  gps_lng double precision,
  unique (session_id, student_id) -- يمنع تسجيل الحضور مرتين لنفس الجلسة
);

-- ---------------------------------------------------------
-- 7) student_devices : ربط "جهاز واحد لكل طالب" — يمنع تسجيل الحضور
-- نيابةً عن طالب آخر من نفس الجهاز (مشاركة الهاتف بين الطلاب).
--
-- device_hash = HMAC-SHA256(DEVICE_ID_HASH_SECRET, deviceId) المحسوب في
-- lib/device.ts. لا يُخزَّن معرّف الجهاز الخام (raw device id) في القاعدة
-- إطلاقًا — فقط ناتج الـ hash.
--
-- القيدان UNIQUE أدناه هما ما يفرض القاعدة فعليًا على مستوى قاعدة
-- البيانات (وليس فقط في كود الواجهة):
--   * student_id UNIQUE → كل طالب له جهاز واحد "نشط" مسجَّل فقط.
--   * device_hash UNIQUE → كل جهاز مرتبط بطالب واحد فقط؛ محاولة طالب
--     آخر تسجيل حضور من نفس الجهاز سترفضها القاعدة بخطأ تعارض (23505)
--     حتى لو حاول كود التطبيق تجاوز الفحص برمجيًا.
-- ---------------------------------------------------------
create table student_devices (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references users_profile(id) on delete cascade,
  device_hash text not null,
  registered_at timestamptz not null default now(),
  constraint student_devices_student_id_key unique (student_id),
  constraint student_devices_device_hash_key unique (device_hash)
);

create index idx_student_devices_student on student_devices(student_id);

-- ---------------------------------------------------------
-- 8) device_reset_log : سجل تدقيق بسيط — من قام بإعادة تعيين جهاز أي
-- طالب ومتى (للمساءلة). لا يمكن للطالب نفسه إنشاء صف هنا (يمر فقط عبر
-- API الدكتور بصلاحية Service Role).
-- ---------------------------------------------------------
create table device_reset_log (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references users_profile(id) on delete cascade,
  reset_by uuid references users_profile(id) on delete set null,
  reset_at timestamptz not null default now()
);

create index idx_device_reset_log_student on device_reset_log(student_id);

-- ---------------------------------------------------------
-- فهارس لتحسين الأداء
-- ---------------------------------------------------------
create index idx_lectures_course on lectures(course_id);
create index idx_sessions_lecture on attendance_sessions(lecture_id);
create index idx_records_session on attendance_records(session_id);
create index idx_records_student on attendance_records(student_id);
create index idx_enrollments_student on enrollments(student_id);
create index idx_enrollments_course on enrollments(course_id);

-- ============================================================
-- Row Level Security (RLS) — راجع ملف policies.sql للتفاصيل الكاملة
-- ============================================================
alter table users_profile enable row level security;
alter table courses enable row level security;
alter table enrollments enable row level security;
alter table lectures enable row level security;
alter table attendance_sessions enable row level security;
alter table attendance_records enable row level security;
alter table student_devices enable row level security;
alter table device_reset_log enable row level security;
