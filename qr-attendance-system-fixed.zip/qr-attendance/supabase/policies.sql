-- ============================================================
-- Row Level Security Policies
-- المبدأ: كل الكتابة الحساسة (تسجيل حضور، فتح/غلق جلسة) تمر عبر
-- Next.js API Routes باستخدام الـ Service Role (Server-side فقط)،
-- بينما القراءة العادية تُقيَّد بهذه السياسات حتى لو استُخدم مفتاح anon.
-- ============================================================

-- users_profile: كل مستخدم يرى ملفه الشخصي فقط، والدكتور يرى طلابه المسجلين معه
create policy "read own profile"
on users_profile for select
using (auth.uid() = id);

-- إصلاح: بدون هذه السياسة، أي استعلام من صفحات الدكتور (نسب الحضور /
-- تصدير التقرير / سجل طالب) يجلب users_profile عبر عميل الجلسة العادي
-- (وليس Service Role)، وبما أنها مربوطة بـ !inner join فإن RLS يحذف
-- الصف كاملاً لأي طالب غير الدكتور نفسه — أي أن الجدول كان سيظهر فارغًا
-- دائمًا رغم وجود طلاب مسجَّلين فعليًا. هذه السياسة تسمح للدكتور تحديدًا
-- بقراءة ملفات الطلاب المسجَّلين في أحد مقرراته التي يملكها هو.
create policy "lecturer reads profiles of own enrolled students"
on users_profile for select
using (
  exists (
    select 1
    from enrollments e
    join courses c on c.id = e.course_id
    where e.student_id = users_profile.id
      and c.lecturer_id = auth.uid()
  )
);

-- courses: الدكتور صاحب المقرر فقط يديره
create policy "lecturer manages own courses"
on courses for all
using (auth.uid() = lecturer_id)
with check (auth.uid() = lecturer_id);

-- enrollments: الدكتور صاحب المقرر يدير التسجيل، والطالب يرى تسجيله فقط
create policy "lecturer manages enrollments"
on enrollments for all
using (
  exists (select 1 from courses c where c.id = course_id and c.lecturer_id = auth.uid())
);

create policy "student reads own enrollment"
on enrollments for select
using (auth.uid() = student_id);

-- lectures: الدكتور صاحب المقرر فقط
create policy "lecturer manages lectures"
on lectures for all
using (
  exists (select 1 from courses c where c.id = course_id and c.lecturer_id = auth.uid())
);

-- الطالب المسجل بالمقرر يمكنه فقط قراءة (وليس تعديل) محاضرات مقرراته
create policy "enrolled student reads lectures"
on lectures for select
using (
  exists (
    select 1 from enrollments e
    where e.course_id = lectures.course_id and e.student_id = auth.uid()
  )
);

-- attendance_sessions: القراءة فقط لصاحب المقرر أو الطالب المسجل (بدون كتابة مباشرة أبدًا)
create policy "lecturer manages sessions"
on attendance_sessions for all
using (
  exists (
    select 1 from lectures l join courses c on c.id = l.course_id
    where l.id = lecture_id and c.lecturer_id = auth.uid()
  )
);

-- attendance_records: لا يوجد INSERT مباشر مسموح به من العميل إطلاقًا؛
-- التسجيل يتم حصرًا عبر API Route بصلاحية Service Role بعد كل التحققات.
create policy "lecturer reads course attendance"
on attendance_records for select
using (
  exists (
    select 1 from attendance_sessions s
    join lectures l on l.id = s.lecture_id
    join courses c on c.id = l.course_id
    where s.id = session_id and c.lecturer_id = auth.uid()
  )
);

create policy "student reads own attendance"
on attendance_records for select
using (auth.uid() = student_id);

-- لا نضيف "with check" لـ insert/update على attendance_records للعميل مطلقًا —
-- بذلك أي محاولة INSERT من متصفح الطالب مباشرة (تجاوز الـ API) سترفضها قاعدة البيانات.

-- student_devices و device_reset_log: عمدًا بدون أي policy إطلاقًا.
-- تفعيل RLS بدون أي policy = رفض كل وصول افتراضيًا (حتى SELECT) لأي طلب
-- يستخدم مفتاح anon/authenticated من المتصفح. كل القراءة والكتابة على
-- هذين الجدولين تمر حصرًا عبر API Routes بصلاحية Service Role بعد تحقق
-- الصلاحيات يدويًا في الكود (انظر lib/device.ts و
-- app/api/attendance/confirm و app/api/courses/[courseId]/students/[studentId]/device/reset).
-- هذا يضمن أن الطالب لا يمكنه أبدًا قراءة/حذف/تعديل سجل جهازه بنفسه،
-- وأن "إعادة تعيين الجهاز" ممكنة فقط من طرف الدكتور صاحب المقرر.
