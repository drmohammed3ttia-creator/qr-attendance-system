-- ============================================================
-- Migration 002: One device = one student
-- ============================================================
-- طبّق هذا الملف على أي مشروع Supabase قائم بالفعل (نفّذه في SQL Editor
-- مرة واحدة). المشاريع الجديدة تحصل على نفس هذا الأثر تلقائيًا من
-- supabase/schema.sql + supabase/policies.sql المحدَّثين.
--
-- ما يفعله هذا الملف:
--   1) ينشئ جدول student_devices لربط كل طالب بجهاز واحد فقط (hash فقط،
--      وليس معرّف الجهاز الخام) عبر قيدي UNIQUE (على student_id وعلى
--      device_hash) — القيد الحقيقي المانع هو في قاعدة البيانات نفسها،
--      وليس في كود التطبيق.
--   2) ينشئ جدول device_reset_log كسجل تدقيق لعمليات إعادة التعيين.
--   3) يفعّل RLS على الجدولين بدون أي policy (رفض افتراضي لأي وصول من
--      المتصفح) — الوصول فقط عبر Service Role من داخل API Routes.
--
-- هذا الملف idempotent قدر الإمكان (يستخدم if not exists) بحيث يمكن
-- إعادة تشغيله بأمان لو نُفِّذ جزئيًا من قبل.
-- ============================================================

create table if not exists student_devices (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references users_profile(id) on delete cascade,
  device_hash text not null,
  registered_at timestamptz not null default now(),
  constraint student_devices_student_id_key unique (student_id),
  constraint student_devices_device_hash_key unique (device_hash)
);

create index if not exists idx_student_devices_student on student_devices(student_id);

create table if not exists device_reset_log (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references users_profile(id) on delete cascade,
  reset_by uuid references users_profile(id) on delete set null,
  reset_at timestamptz not null default now()
);

create index if not exists idx_device_reset_log_student on device_reset_log(student_id);

alter table student_devices enable row level security;
alter table device_reset_log enable row level security;

-- عمدًا بدون أي CREATE POLICY هنا — راجع التعليق في supabase/policies.sql
-- لتفسير سبب ترك هذين الجدولين بدون أي policy عن قصد.
