/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,ts,jsx,tsx}", "./components/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#eef4ff", 100: "#dbe7ff", 500: "#3b5bdb",
          600: "#3049b8", 700: "#263b91", 900: "#1a285f"
        }
      }
    },
  },
  plugins: [],
};
